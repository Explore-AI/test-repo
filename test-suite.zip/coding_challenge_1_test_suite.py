"""
Test suite for Coding Challenge 1 python test
"""
import pytest
import submission as Submission

@pytest.mark.timeout(5)
@pytest.mark.parametrize("test_input", [
    ([['mix', 'xyz', 'apple', 'xanadu', 'aardvark']])
])
def test_return_type_is_list(test_input):
    """
    Test the front_x method's return type
    """
    assert isinstance(Submission.front_x(*test_input), type([]))

@pytest.mark.timeout(5)
@pytest.mark.parametrize("test_input,expected_output", [
    ([['mix', 'xyz', 'apple', 'xanadu', 'aardvark']],
     ['xanadu', 'xyz', 'aardvark', 'apple', 'mix']),
    ([['netowrk', 'artist', 'xamarian', 'king', 'cat']],
     ['xamarian', 'artist', 'cat', 'king', 'netowrk']),
    ([['jhsdfi', 'jeiri', 'iopqwu', 'bhvaiau', 'loaks']],
     ['bhvaiau', 'iopqwu', 'jeiri', 'jhsdfi', 'loaks'])
])
def test_front_x(test_input, expected_output):
    """
    test front_x method
    """
    actual_output = Submission.front_x(*test_input)
    assert  actual_output == expected_output

@pytest.mark.timeout(5)
@pytest.mark.parametrize("test_input,expected_output", [
    ([['today', 'lopepu', 'bjahs', 'aajdha', 'xoireutnf']],
     ['xoireutnf', 'aajdha', 'bjahs', 'lopepu', 'today']),
    ([['jhsdfi', 'jeiri', 'iopqwu', 'bhvaiau', 'loaks']],
     ['bhvaiau', 'iopqwu', 'jeiri', 'jhsdfi', 'loaks'])
])
def test_front_x_unseen(test_input, expected_output):
    """
    test front_x method with unseen cases
    """
    actual_output = Submission.front_x(*test_input)
    assert  actual_output == expected_output

@pytest.mark.timeout(15)
@pytest.mark.parametrize("test_input, expected_output", [
    (['AUGUAGCAUAA'], 5),
    (['AUGUUAUAG'], 3),
    (['AUGUAGGCACAUUUAUGCUCCUGA'], 18),
    (['AUGAGGCACCUUCUGCUCCUUAC'], "Not readable RNA code")
])
def test_rna_length(test_input, expected_output):
    """
    test rna_length method
    """
    actual_output = Submission.rna_length(*test_input)
    assert actual_output == expected_output

@pytest.mark.timeout(15)
@pytest.mark.parametrize("test_input, expected_output", [
    (['AUCUGAGAAUAA'], "Not readable RNA code"),
    (['AUGUGACAUUUACUGA'], 10),
    (['AUGUAG'], 0),
    (['AUGUAGAUGUAGAUGUAG'], 12)
])
def test_rna_length_unseen(test_input, expected_output):
    """
    test rna_length method with unseen cases
    """
    actual_output = Submission.rna_length(*test_input)
    assert actual_output == expected_output
